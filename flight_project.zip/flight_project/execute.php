<?php
$host = "localhost";
$user = "root";         // your MySQL username
$password = "";         // your MySQL password
$database = "flight_db"; // your DB name

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = $_POST['sql_query'];
?>

<!DOCTYPE html>
<html>
<head>
  <title>Query Result</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(120deg, #0f2027, #203a43, #2c5364);
      color: #fff;
      padding: 30px;
    }
    .container {
      background: rgba(255,255,255,0.1);
      backdrop-filter: blur(8px);
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 8px 30px rgba(0,0,0,0.3);
      margin-top: 50px;
    }
    h2 {
      text-align: center;
      margin-bottom: 25px;
      font-weight: bold;
      color: #00e6e6;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.4);
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 15px;
      color: #fff;
    }
    table, th, td {
      border: 1px solid #ccc;
      padding: 8px;
      text-align: center;
    }
    th {
      background-color: rgba(0,0,0,0.3);
      color: #00e6e6;
    }
    td {
      background-color: rgba(255,255,255,0.05);
    }
    .btn-custom {
      background: #00e6e6;
      color: #0f2027;
      font-weight: bold;
      border-radius: 8px;
      padding: 8px 18px;
      text-decoration: none;
      display: inline-block;
      margin-top: 20px;
      transition: 0.3s;
      box-shadow: 0 0 10px #00e6e6, 0 0 20px #00e6e6;
    }
    .btn-custom:hover {
      background: #00cccc;
      box-shadow: 0 0 20px #00cccc, 0 0 30px #00cccc;
      color: #fff;
    }
    .error-msg {
      color: #ff6666;
      font-weight: bold;
      text-align: center;
      margin-top: 20px;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Query Result</h2>

    <?php
    if (trim($sql) == "") {
      echo "<p class='error-msg'>⚠ No SQL query provided.</p>";
    } else if (stripos($sql, "select") === 0) {
      $result = $conn->query($sql);
      if ($result && $result->num_rows > 0) {
        echo "<table>";
        echo "<tr>";
        while ($field = $result->fetch_field()) {
          echo "<th>" . htmlspecialchars($field->name) . "</th>";
        }
        echo "</tr>";
        while ($row = $result->fetch_assoc()) {
          echo "<tr>";
          foreach ($row as $data) {
            echo "<td>" . htmlspecialchars($data) . "</td>";
          }
          echo "</tr>";
        }
        echo "</table>";
      } else {
        echo "<p>No results found.</p>";
      }
    } else {
      if ($conn->query($sql) === TRUE) {
        echo "<p>✅ <strong>Query executed successfully.</strong></p>";
      } else {
        echo "<p>❌ <strong>Error:</strong> " . $conn->error . "</p>";
      }
    }
    ?>

    <div class="text-center">
      <a href="index.html" class="btn-custom">⬅️ Back to Home</a>
    </div>
  </div>

</body>
</html>

<?php
$conn->close();
?>
